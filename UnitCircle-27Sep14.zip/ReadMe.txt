Product: Unit Circle, September 2014

Designer: Zombie Cat, http://zombie-cat.org/

Support:  http://forums.obrary.com/category/designs/unit-circle

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
Here's a teaching tool that shows the relationship between unit circles and sine waves.  This laser cut pieces has the circle into 15 degree increments which can be pulled flat to show the sine curve.